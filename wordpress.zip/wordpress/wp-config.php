<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'root');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'K,wWwa]5>5nbWeI:^@YWB`%?lqL`baWJ!#qqMq,]H:*4&iOootgj_7 !V(bk.-?]');
define('SECURE_AUTH_KEY',  'Y$7A<Db>hHE5%=zE(HAnQv[Q*KaCtl@LE[:7;pj+4P;XIOu]34$:)&Nn?5>cmPOD');
define('LOGGED_IN_KEY',    'CM4ZWy34a_3sV9UZ/%KG2![5m!^.ap^5<Ze$u$E]<cw0Gj>>,6ttyc/>[*GJ?=Qg');
define('NONCE_KEY',        'iQCUZp*_=m;T%?W!*0QA+`L]>[nE5qHe;&HduZw?))Dc)AU`Ye>/G!(Z`n*5[ kk');
define('AUTH_SALT',        '&6%Cgz/r<AwiY)o:ya9Y-L |eZVvn{cg)>2Ofva]R$unUuLuZ/R~.)&1|f*dzZd5');
define('SECURE_AUTH_SALT', ' ~mH|aK&fDh|orMH:/{D=O7mv<;nA-[QSy^A=HO}H1d^QmLTY|c$S4(dDmuc4+eA');
define('LOGGED_IN_SALT',   'F0u*K{;9s/8:/nGi|yZwG{F=,)65lHZEwzX_9nt%e]/A)%U7GM1w?C&a[G+z$Mq^');
define('NONCE_SALT',       'UL6@2o4oo)-b8{V.($s7=_Q)LQ_Bw[4J2D/t,cAD}LR%fLY<mG/|7&rc6/h457,d');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
